# Gtag-Mod-Menu
Gtag Mod menu
Download python https://www.python.org/downloads/ you have to or this wont work
right click on setup and press enter on your key board
trust its very good

